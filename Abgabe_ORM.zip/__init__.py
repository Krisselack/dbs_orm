# Python script 
# File: __init__.py
# Author: Christian Brandstätter 
# Contact: bran.chri@gmail.com
# Date:  3.06.2020
# Copyright (C) 2020
# Description: leeres File für den Modulimport

