def printconsole(text):
        print(text)
def getinput():
        userinput = input()
        return userinput
def get_country():
    printconsole('Please enter the country you are searching for: ')
    return getinput()